import React, { useState } from 'react';
import { Board, Position, Piece } from '../types/chess';
import { Square } from './Square';
import { getInitialBoard, getValidMoves, movePiece } from '../utils/chess';

export function ChessBoard() {
  const [board, setBoard] = useState<Board>(getInitialBoard());
  const [selectedSquare, setSelectedSquare] = useState<Position | null>(null);
  const [currentPlayer, setCurrentPlayer] = useState<'white' | 'black'>('white');
  const [validMoves, setValidMoves] = useState<Position[]>([]);

  const handleSquareClick = (position: Position) => {
    if (!selectedSquare) {
      const piece = board[position.y][position.x].piece;
      if (piece && piece.color === currentPlayer) {
        setSelectedSquare(position);
        setValidMoves(getValidMoves(board, position));
      }
    } else {
      const isValidMove = validMoves.some(
        move => move.x === position.x && move.y === position.y
      );

      if (isValidMove) {
        const newBoard = movePiece(board, selectedSquare, position);
        setBoard(newBoard);
        setCurrentPlayer(currentPlayer === 'white' ? 'black' : 'white');
      }

      setSelectedSquare(null);
      setValidMoves([]);
    }
  };

  const isValidMove = (position: Position) =>
    validMoves.some(move => move.x === position.x && move.y === position.y);

  return (
    <div className="p-8 bg-gray-800 rounded-lg shadow-xl">
      <div className="mb-4 text-white text-xl font-semibold">
        Current Player: {currentPlayer}
      </div>
      <div className="grid grid-cols-8 gap-0 border-4 border-gray-700">
        {board.map((row, y) =>
          row.map((square, x) => (
            <Square
              key={`${x}-${y}`}
              square={square}
              isSelected={
                selectedSquare?.x === x && selectedSquare?.y === y
              }
              isValidMove={isValidMove({ x, y })}
              onClick={() => handleSquareClick({ x, y })}
            />
          ))
        )}
      </div>
    </div>
  );
}