import React from 'react';
import { Square as SquareType } from '../types/chess';

interface SquareProps {
  square: SquareType;
  isSelected: boolean;
  isValidMove: boolean;
  onClick: () => void;
}

export function Square({ square, isSelected, isValidMove, onClick }: SquareProps) {
  const { position, piece } = square;
  const isBlackSquare = (position.x + position.y) % 2 === 1;

  const getPieceSymbol = () => {
    if (!piece) return '';
    const symbols: Record<string, string> = {
      'white-king': '♔',
      'white-queen': '♕',
      'white-rook': '♖',
      'white-bishop': '♗',
      'white-knight': '♘',
      'white-pawn': '♙',
      'black-king': '♚',
      'black-queen': '♛',
      'black-rook': '♜',
      'black-bishop': '♝',
      'black-knight': '♞',
      'black-pawn': '♟',
    };
    return symbols[`${piece.color}-${piece.type}`];
  };

  return (
    <div
      onClick={onClick}
      className={`
        w-16 h-16 flex items-center justify-center text-4xl cursor-pointer
        ${isBlackSquare ? 'bg-gray-600' : 'bg-gray-200'}
        ${isSelected ? 'ring-4 ring-blue-400' : ''}
        ${isValidMove ? 'ring-4 ring-green-400' : ''}
        ${piece?.color === 'white' ? 'text-white' : 'text-black'}
        hover:opacity-90 transition-opacity
      `}
    >
      {getPieceSymbol()}
    </div>
  );
}