import { Board, Position, Piece, PieceType, Square } from '../types/chess';

export function getInitialBoard(): Board {
  const board: Board = Array(8)
    .fill(null)
    .map((_, y) =>
      Array(8)
        .fill(null)
        .map((_, x) => ({
          piece: null,
          position: { x, y },
        }))
    );

  // Set up pawns
  for (let x = 0; x < 8; x++) {
    board[1][x].piece = { type: 'pawn', color: 'black' };
    board[6][x].piece = { type: 'pawn', color: 'white' };
  }

  // Set up other pieces
  const backRowPieces: PieceType[] = [
    'rook',
    'knight',
    'bishop',
    'queen',
    'king',
    'bishop',
    'knight',
    'rook',
  ];

  backRowPieces.forEach((type, x) => {
    board[0][x].piece = { type, color: 'black' };
    board[7][x].piece = { type, color: 'white' };
  });

  return board;
}

function isValidPosition(x: number, y: number): boolean {
  return x >= 0 && x < 8 && y >= 0 && y < 8;
}

function addMove(
  moves: Position[],
  board: Board,
  x: number,
  y: number,
  piece: Piece
): boolean {
  if (!isValidPosition(x, y)) return false;
  
  const targetPiece = board[y][x].piece;
  if (targetPiece && targetPiece.color === piece.color) return false;
  
  moves.push({ x, y });
  return targetPiece === null;
}

function getDiagonalMoves(board: Board, position: Position, piece: Piece): Position[] {
  const moves: Position[] = [];
  const directions = [
    { dx: 1, dy: 1 },
    { dx: 1, dy: -1 },
    { dx: -1, dy: 1 },
    { dx: -1, dy: -1 }
  ];

  directions.forEach(({ dx, dy }) => {
    let x = position.x + dx;
    let y = position.y + dy;
    while (isValidPosition(x, y)) {
      if (!addMove(moves, board, x, y, piece)) break;
      x += dx;
      y += dy;
    }
  });

  return moves;
}

function getStraightMoves(board: Board, position: Position, piece: Piece): Position[] {
  const moves: Position[] = [];
  const directions = [
    { dx: 0, dy: 1 },
    { dx: 0, dy: -1 },
    { dx: 1, dy: 0 },
    { dx: -1, dy: 0 }
  ];

  directions.forEach(({ dx, dy }) => {
    let x = position.x + dx;
    let y = position.y + dy;
    while (isValidPosition(x, y)) {
      if (!addMove(moves, board, x, y, piece)) break;
      x += dx;
      y += dy;
    }
  });

  return moves;
}

export function getValidMoves(board: Board, position: Position): Position[] {
  const piece = board[position.y][position.x].piece;
  if (!piece) return [];

  const moves: Position[] = [];
  const { type, color } = piece;

  switch (type) {
    case 'pawn': {
      const direction = color === 'white' ? -1 : 1;
      const startRow = color === 'white' ? 6 : 1;

      // Forward move
      if (
        isValidPosition(position.x, position.y + direction) &&
        !board[position.y + direction][position.x].piece
      ) {
        moves.push({ x: position.x, y: position.y + direction });

        // Double move from starting position
        if (
          position.y === startRow &&
          !board[position.y + direction * 2][position.x].piece
        ) {
          moves.push({ x: position.x, y: position.y + direction * 2 });
        }
      }

      // Capture moves
      [-1, 1].forEach(dx => {
        const newX = position.x + dx;
        const newY = position.y + direction;
        if (
          isValidPosition(newX, newY) &&
          board[newY][newX].piece?.color === (color === 'white' ? 'black' : 'white')
        ) {
          moves.push({ x: newX, y: newY });
        }
      });
      break;
    }

    case 'knight': {
      const knightMoves = [
        { dx: 2, dy: 1 },
        { dx: 2, dy: -1 },
        { dx: -2, dy: 1 },
        { dx: -2, dy: -1 },
        { dx: 1, dy: 2 },
        { dx: 1, dy: -2 },
        { dx: -1, dy: 2 },
        { dx: -1, dy: -2 }
      ];

      knightMoves.forEach(({ dx, dy }) => {
        const x = position.x + dx;
        const y = position.y + dy;
        if (isValidPosition(x, y)) {
          const targetPiece = board[y][x].piece;
          if (!targetPiece || targetPiece.color !== color) {
            moves.push({ x, y });
          }
        }
      });
      break;
    }

    case 'bishop':
      moves.push(...getDiagonalMoves(board, position, piece));
      break;

    case 'rook':
      moves.push(...getStraightMoves(board, position, piece));
      break;

    case 'queen':
      moves.push(
        ...getDiagonalMoves(board, position, piece),
        ...getStraightMoves(board, position, piece)
      );
      break;

    case 'king': {
      const kingMoves = [
        { dx: -1, dy: -1 },
        { dx: -1, dy: 0 },
        { dx: -1, dy: 1 },
        { dx: 0, dy: -1 },
        { dx: 0, dy: 1 },
        { dx: 1, dy: -1 },
        { dx: 1, dy: 0 },
        { dx: 1, dy: 1 }
      ];

      kingMoves.forEach(({ dx, dy }) => {
        const x = position.x + dx;
        const y = position.y + dy;
        if (isValidPosition(x, y)) {
          const targetPiece = board[y][x].piece;
          if (!targetPiece || targetPiece.color !== color) {
            moves.push({ x, y });
          }
        }
      });
      break;
    }
  }

  return moves;
}

export function movePiece(
  board: Board,
  from: Position,
  to: Position
): Board {
  const newBoard = board.map(row =>
    row.map(square => ({
      ...square,
      piece: square.piece ? { ...square.piece } : null,
    }))
  );

  const piece = newBoard[from.y][from.x].piece;
  newBoard[to.y][to.x].piece = piece;
  newBoard[from.y][from.x].piece = null;

  return newBoard;
}