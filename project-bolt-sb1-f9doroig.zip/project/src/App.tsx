import React from 'react';
import { ChessBoard } from './components/ChessBoard';

function App() {
  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-white mb-8">React Chess</h1>
        <ChessBoard />
      </div>
    </div>
  );
}

export default App;